console.log("✅ Content script loaded! Waiting for messages...");

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("📩 Message received in content script:", message);
  
    if (message.action === "capturePhoto") {
        console.log("📷 Capturing photo...");

        let video = document.createElement("video");
        video.autoplay = true;
        video.style.display = "none";
        document.body.appendChild(video);

        navigator.mediaDevices.getUserMedia({ video: true })
            .then((stream) => {
                video.srcObject = stream;

                setTimeout(() => {
                    let canvas = document.createElement("canvas");
                    let context = canvas.getContext("2d");

                    canvas.width = video.videoWidth;
                    canvas.height = video.videoHeight;
                    context.drawImage(video, 0, 0, canvas.width, canvas.height);

                    let imageDataURL = canvas.toDataURL("image/png");
                    console.log("✅ Photo captured:", imageDataURL);

                    // Stop the webcam
                    stream.getTracks().forEach(track => track.stop());

                    // Save the image in localStorage
                    localStorage.setItem("capturedPhoto", imageDataURL);

                    // Send the captured image to the popup
                    chrome.runtime.sendMessage({ action: "updatePhoto", image: imageDataURL });

                    sendResponse({ status: "success", image: imageDataURL });

                }, 1000);
            })
            .catch((err) => {
                console.error("❌ Error accessing camera:", err);
                sendResponse({ status: "error", message: err.message });
            });

        return true; // Required for async response
    }
});
