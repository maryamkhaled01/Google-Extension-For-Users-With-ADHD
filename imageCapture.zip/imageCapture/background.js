console.log("✅ Background script loaded");

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("📩 Message received in background:", message);

  if (message.action === "startCapture") {
    console.log("⏳ Starting photo capture every 2 minutes...");
    chrome.alarms.create("capturePhoto", { periodInMinutes: 2 });
  } else if (message.action === "stopCapture") {
    console.log("🛑 Stopping photo capture");
    chrome.alarms.clear("capturePhoto");
  }
});

chrome.alarms.onAlarm.addListener((alarm) => {
  console.log("⏰ Alarm triggered:", alarm.name);

  if (alarm.name === "capturePhoto") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || tabs.length === 0) {
        console.warn("⚠ No active tab found. Cannot inject content script.");
        return;
      }

      let tabId = tabs[0].id;

      chrome.scripting.executeScript(
        {
          target: { tabId: tabId },
          files: ["content.js"]
        },
        () => {
          if (chrome.runtime.lastError) {
            console.error("❌ Script injection failed:", chrome.runtime.lastError.message);
            return;
          }

          console.log("📨 Sending capturePhoto message to content script...");
          chrome.tabs.sendMessage(tabId, { action: "capturePhoto" }, (response) => {
            if (chrome.runtime.lastError) {
              console.error("❌ Error sending message:", chrome.runtime.lastError.message);
            } else {
              console.log("✅ Message sent successfully!");
            }
          });
        }
      );
    });
  }
});
