document.addEventListener("DOMContentLoaded", () => {
    let startButton = document.getElementById("start");
    let stopButton = document.getElementById("stop");
    let photoImg = document.getElementById("photo");

    // Load the last captured photo from localStorage
    let savedPhoto = localStorage.getItem("capturedPhoto");
    if (savedPhoto) {
        photoImg.src = savedPhoto;
        photoImg.style.display = "block";
    }

    startButton.addEventListener("click", () => {
        chrome.runtime.sendMessage({ action: "startCapture" });
    });

    stopButton.addEventListener("click", () => {
        chrome.runtime.sendMessage({ action: "stopCapture" });
    });

    // Listen for messages from content.js
    chrome.runtime.onMessage.addListener((message) => {
        if (message.action === "updatePhoto" && message.image) {
            photoImg.src = message.image;
            photoImg.style.display = "block";
            localStorage.setItem("capturedPhoto", message.image);
        }
    });
});
